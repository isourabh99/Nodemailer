const nodemailer = require("nodemailer");

module.exports.sendMail=async (req,res,user)=>{
    const transport = nodemailer.createTransport({
        host: "smtp.ethereal.email",
        port: 587,
        service:"Gmail",
        auth: {
            user: "mrsourabh05@gmail.com",
            pass: "ohogydyaydmwzekb",
        },
    });

    const info = await transport.sendMail({
        from: '"Hi Welcome to our page 👻" <mrsourabh05@gmail.com>', // sender address
        to: req.body.email, // list of receivers
        subject: `welcome ${req.body.username}`, // Subject line
        text: `${req.body.username} You are now subscribed to our page.....`, // plain text body
    });
    transport.sendMail(info,(err,info)=>{
        if(err) return res.send(err)
      console.log("mail sent");
    return res.send("Email sent please check your inbox")
    })
}